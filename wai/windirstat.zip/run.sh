#!/bin/bash

# bacic installer example
PREINSTALLEDIR="./wine/drive_c/Program Files/WinDirStat/WinDirStat.exe"
INSTLLER="wds.msi"

if [ -f "$PREINSTALLEDIR" ]; then
    wine "$PREINSTALLEDIR"
else
    wine "$INSTLLER"
fi
