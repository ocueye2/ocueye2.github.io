#!/bin/bash

# bacic installer example
PREINSTALLEDIR="./wine/drive_c/Program Files/Notepad++/notepad++.exa st nn t it INSTLLER="npp.exe"

if [ -f "$PREINSTALLEDIR" ]; then
    wine "$PREINSTALLEDIR"
else
    wine "$INSTLLER"
fi
