#!/bin/bash

# bacic installer example
PREINSTALLEDIR="./wine/drive_c/Program Files/Notepad++/notepad++.exe"
INSTLLER="npp.exe"

if [ -f "$PREINSTALLEDIR" ]; then
    wine "$PREINSTALLEDIR"
else
    wine "$INSTLLER"
fi
